import java.io.*;

public class Tugas16 {
    public static void main(String[] args) {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        try {
            System.out.print("masukkan nilai a: ");
            double a = Double.parseDouble(reader.readLine());
            System.out.print("masukkan nilai b: ");
            double b = Double.parseDouble(reader.readLine());
            System.out.print("masukkan nilai c: ");
            double c = Double.parseDouble(reader.readLine());
            double hasil = a + (b * c);
            
            System.out.println("hasil dari a + b * c adalah: " + hasil);
        } catch (IOException | NumberFormatException e) {
    }
}
}